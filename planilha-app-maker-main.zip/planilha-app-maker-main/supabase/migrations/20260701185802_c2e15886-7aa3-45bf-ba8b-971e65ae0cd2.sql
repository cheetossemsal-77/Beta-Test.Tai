
CREATE TABLE public.assessments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  empresa TEXT NOT NULL DEFAULT '',
  setor TEXT NOT NULL DEFAULT '',
  cargo TEXT NOT NULL DEFAULT '',
  data_visita DATE,
  form_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.assessments TO authenticated;
GRANT ALL ON public.assessments TO service_role;

ALTER TABLE public.assessments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own assessments select" ON public.assessments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "own assessments insert" ON public.assessments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own assessments update" ON public.assessments FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own assessments delete" ON public.assessments FOR DELETE USING (auth.uid() = user_id);

CREATE INDEX assessments_user_created_idx ON public.assessments (user_id, created_at DESC);

CREATE OR REPLACE FUNCTION public.update_updated_at_column() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_assessments_updated_at BEFORE UPDATE ON public.assessments
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
