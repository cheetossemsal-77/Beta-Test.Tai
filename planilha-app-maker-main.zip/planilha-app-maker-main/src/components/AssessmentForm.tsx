import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Trash2, Plus, Download, Save, ArrowLeft } from "lucide-react";
import {
  RISK_GROUPS,
  EPI_GROUPS,
  emptyAssessment,
  riskLevel,
  type AssessmentData,
  type PlanoAcaoItem,
} from "@/lib/assessment-schema";
import { downloadAssessmentPDF } from "@/lib/generate-pdf";

type Props = {
  initial?: AssessmentData;
  id?: string;
};

const emptyPlano = (): PlanoAcaoItem => ({
  medida: "",
  g: "",
  u: "",
  t: "",
  porque: "",
  quando: "",
  onde: "",
  como: "",
  abrangencia: "",
});

export function AssessmentForm({ initial, id }: Props) {
  const navigate = useNavigate();
  const [data, setData] = useState<AssessmentData>(initial ?? emptyAssessment());
  const [saving, setSaving] = useState(false);

  function set<K extends keyof AssessmentData>(key: K, value: AssessmentData[K]) {
    setData((d) => ({ ...d, [key]: value }));
  }

  function setRisk(groupKey: string, itemKey: string, field: "s" | "p", value: number) {
    const k = `${groupKey}.${itemKey}`;
    setData((d) => ({
      ...d,
      riscos: { ...d.riscos, [k]: { ...(d.riscos[k] || { s: 0, p: 0 }), [field]: value } },
    }));
  }

  function setEpi(key: string, value: string) {
    setData((d) => ({ ...d, epis: { ...d.epis, [key]: value } }));
  }

  function setFonte(groupKey: string, itemKey: string, value: string) {
    const k = `${groupKey}.${itemKey}`;
    setData((d) => ({ ...d, fontes: { ...d.fontes, [k]: value } }));
  }

  function setObs(groupKey: string, itemKey: string, value: string) {
    const k = `${groupKey}.${itemKey}`;
    setData((d) => ({ ...d, observacoes: { ...d.observacoes, [k]: value } }));
  }

  function updatePlano(idx: number, patch: Partial<PlanoAcaoItem>) {
    setData((d) => ({
      ...d,
      planoAcao: d.planoAcao.map((p, i) => (i === idx ? { ...p, ...patch } : p)),
    }));
  }

  function addPlano() {
    setData((d) => ({ ...d, planoAcao: [...d.planoAcao, emptyPlano()] }));
  }

  function removePlano(idx: number) {
    setData((d) => ({ ...d, planoAcao: d.planoAcao.filter((_, i) => i !== idx) }));
  }

  async function save(): Promise<string | null> {
    // Validação: dados de identificação são todos obrigatórios
    const required: [string, string][] = [
      ["Empresa", data.empresa],
      ["Data da visita", data.data],
      ["Técnico responsável", data.tecnicoResponsavel],
      ["Acompanhado por", data.acompanhadoPor],
      ["Telefone financeiro", data.telefoneFinanceiro],
      ["Email financeiro", data.emailFinanceiro],
      ["Setor", data.setor],
      ["GHE", data.ghe],
      ["Cargo", data.cargo],
      ["Nº de trabalhadores", data.numTrabalhadores],
      ["CBO", data.cbo],
      ["GFIP", data.gfip],
      ["LUX", data.lux],
      ["Insalubridade", data.insalubridade],
      ["Periculosidade 30%", data.periculosidade30],
      ["Atividade proibida <18 anos", data.atividadeMenor18],
      ["Característica da exposição do GHE", data.caracteristicaExposicaoGHE],
      ["Descrição da atividade", data.descricaoAtividade],
    ];
    const missing = required.filter(([, v]) => !v || !String(v).trim()).map(([n]) => n);
    if (missing.length > 0) {
      toast.error(`Preencha os campos obrigatórios: ${missing.join(", ")}`);
      return null;
    }
    setSaving(true);
    const { data: userRes } = await supabase.auth.getUser();
    const uid = userRes.user?.id;
    if (!uid) {
      toast.error("Sessão expirada.");
      setSaving(false);
      return null;
    }
    const payload = {
      user_id: uid,
      empresa: data.empresa,
      setor: data.setor,
      cargo: data.cargo,
      data_visita: data.data || null,
      form_data: data as never,
    };

    if (id) {
      const { error } = await supabase.from("assessments").update(payload).eq("id", id);
      setSaving(false);
      if (error) {
        toast.error(error.message);
        return null;
      }
      toast.success("Levantamento atualizado.");
      return id;
    } else {
      const { data: inserted, error } = await supabase
        .from("assessments")
        .insert(payload)
        .select("id")
        .single();
      setSaving(false);
      if (error) {
        toast.error(error.message);
        return null;
      }
      toast.success("Levantamento salvo.");
      return inserted.id;
    }
  }

  async function saveAndBack() {
    const okId = await save();
    if (okId) navigate({ to: "/app" });
  }

  async function saveAndPDF() {
    const okId = await save();
    if (okId) downloadAssessmentPDF(data);
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="bg-primary text-primary-foreground sticky top-0 z-20">
        <div className="max-w-5xl mx-auto px-6 py-3 flex items-center justify-between gap-3">
          <Button variant="secondary" size="sm" onClick={() => navigate({ to: "/app" })}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
          </Button>
          <h1 className="font-semibold truncate">
            {id ? "Editar levantamento" : "Novo levantamento"}
          </h1>
          <div className="flex gap-2">
            <Button size="sm" variant="secondary" onClick={saveAndBack} disabled={saving}>
              <Save className="h-4 w-4 mr-1" /> Salvar
            </Button>
            <Button size="sm" onClick={saveAndPDF} disabled={saving}>
              <Download className="h-4 w-4 mr-1" /> Salvar + PDF
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-6 space-y-5">
        {/* Identificação */}
        <Card>
          <CardHeader><CardTitle>Identificação</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field required label="Empresa" value={data.empresa} onChange={(v) => set("empresa", v)} />
            <Field required label="Data da visita" type="date" value={data.data} onChange={(v) => set("data", v)} />
            <Field required label="Técnico responsável" value={data.tecnicoResponsavel} onChange={(v) => set("tecnicoResponsavel", v)} />
            <Field required label="Acompanhado por" value={data.acompanhadoPor} onChange={(v) => set("acompanhadoPor", v)} />
            <Field required label="Telefone financeiro" value={data.telefoneFinanceiro} onChange={(v) => set("telefoneFinanceiro", v)} />
            <Field required label="Email financeiro" type="email" value={data.emailFinanceiro} onChange={(v) => set("emailFinanceiro", v)} />
            <Field required label="Setor" value={data.setor} onChange={(v) => set("setor", v)} />
            <Field required label="GHE" value={data.ghe} onChange={(v) => set("ghe", v)} />
            <Field required label="Cargo" value={data.cargo} onChange={(v) => set("cargo", v)} />
            <Field required label="Nº de trabalhadores" type="number" value={data.numTrabalhadores} onChange={(v) => set("numTrabalhadores", v)} />
            <Field required label="CBO" value={data.cbo} onChange={(v) => set("cbo", v)} />
            <Field required label="GFIP" value={data.gfip} onChange={(v) => set("gfip", v)} />
            <Field required label="LUX" value={data.lux} onChange={(v) => set("lux", v)} />

            <div className="space-y-1">
              <Label>Insalubridade <span className="text-destructive">*</span></Label>
              <Select value={data.insalubridade} onValueChange={(v) => set("insalubridade", v as AssessmentData["insalubridade"])}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="nao">Não</SelectItem>
                  <SelectItem value="0.1">10%</SelectItem>
                  <SelectItem value="0.2">20%</SelectItem>
                  <SelectItem value="0.4">40%</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <YesNo required label="Periculosidade 30%" value={data.periculosidade30} onChange={(v) => set("periculosidade30", v)} />
            <YesNo required label="Atividade proibida para menores de 18 anos" value={data.atividadeMenor18} onChange={(v) => set("atividadeMenor18", v)} />

            <div className="md:col-span-2 space-y-1">
              <Label>Característica da exposição do GHE <span className="text-destructive">*</span></Label>
              <Textarea rows={2} value={data.caracteristicaExposicaoGHE} onChange={(e) => set("caracteristicaExposicaoGHE", e.target.value)} />
            </div>
            <div className="md:col-span-2 space-y-1">
              <Label>Descrição da atividade <span className="text-destructive">*</span></Label>
              <Textarea rows={3} value={data.descricaoAtividade} onChange={(e) => set("descricaoAtividade", e.target.value)} />
            </div>
          </CardContent>
        </Card>

        {/* Legenda */}
        <Card className="bg-accent/40 border-accent">
          <CardContent className="py-3 text-xs space-y-1">
            <p><strong>Severidade:</strong> 1 Insignificante · 2 Menor · 3 Moderada · 4 Maior · 5 Catastrófica</p>
            <p><strong>Probabilidade:</strong> 1 Quase impossível · 2 Raro · 3 Improvável · 4 Provável · 5 Quase certo</p>
          </CardContent>
        </Card>

        {/* Grupos de risco */}
        {RISK_GROUPS.map((group) => (
          <Card key={group.key}>
            <CardHeader><CardTitle>{group.title}</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {group.items.map((it) => {
                const k = `${group.key}.${it.key}`;
                const r = data.riscos[k] || { s: 0, p: 0 };
                const showLevel = r.s > 0 && r.p > 0;
                const lvl = showLevel ? riskLevel(r.s, r.p) : null;
                return (
                  <div key={it.key} className="border-b pb-3 last:border-0 space-y-2">
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-2 items-center">
                      <div className="md:col-span-5 text-sm font-medium">{it.label}</div>
                      <div className="md:col-span-3">
                        <RatingScale value={r.s} onChange={(v) => setRisk(group.key, it.key, "s", v)} title="Sev" />
                      </div>
                      <div className="md:col-span-3">
                        <RatingScale value={r.p} onChange={(v) => setRisk(group.key, it.key, "p", v)} title="Prob" />
                      </div>
                      <div className="md:col-span-1 text-xs text-right">
                        {lvl && (
                          <span
                            className="px-2 py-0.5 rounded text-white text-[10px] font-bold whitespace-nowrap"
                            style={{ backgroundColor: `rgb(${lvl.color.join(",")})` }}
                          >
                            {lvl.label}
                          </span>
                        )}
                      </div>
                    </div>
                    {it.hasFonte && (
                      <div className="space-y-1">
                        <Label className="text-xs">Fonte</Label>
                        <Input
                          value={data.fontes?.[k] || ""}
                          onChange={(e) => setFonte(group.key, it.key, e.target.value)}
                          placeholder="Informe a fonte"
                        />
                      </div>
                    )}
                    {it.hasObs && (
                      <div className="space-y-1">
                        <Label className="text-xs">Observação</Label>
                        <Textarea
                          rows={2}
                          value={data.observacoes?.[k] || ""}
                          onChange={(e) => setObs(group.key, it.key, e.target.value)}
                        />
                      </div>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>
        ))}

        {/* EPIs */}
        <Card>
          <CardHeader><CardTitle>EPIs existentes / EPCs</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {EPI_GROUPS.map((g) => (
              <div key={g.key} className="space-y-1">
                <Label>{g.label}</Label>
                <Textarea rows={2} value={data.epis[g.key] || ""} onChange={(e) => setEpi(g.key, e.target.value)} />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Plano de ação */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Plano de Ação (Matriz GUT)</CardTitle>
            <Button variant="outline" size="sm" onClick={addPlano}>
              <Plus className="h-4 w-4 mr-1" /> Adicionar item
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-xs text-muted-foreground">
              G = Gravidade · U = Urgência · T = Tendência · valores de 1 a 5.
            </p>
            {data.planoAcao.length === 0 && (
              <p className="text-sm text-muted-foreground">Nenhuma medida adicionada.</p>
            )}
            {data.planoAcao.map((p, i) => (
              <div key={i} className="border rounded-md p-3 space-y-2 bg-background">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-semibold">Medida {i + 1}</span>
                  <Button variant="ghost" size="sm" onClick={() => removePlano(i)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
                <div className="space-y-1">
                  <Label>O quê? (medida de prevenção)</Label>
                  <Textarea rows={2} value={p.medida} onChange={(e) => updatePlano(i, { medida: e.target.value })} />
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <NumField label="G" value={p.g} onChange={(v) => updatePlano(i, { g: v })} />
                  <NumField label="U" value={p.u} onChange={(v) => updatePlano(i, { u: v })} />
                  <NumField label="T" value={p.t} onChange={(v) => updatePlano(i, { t: v })} />
                </div>
                <div className="space-y-1">
                  <Label>Por quê?</Label>
                  <Input value={p.porque} onChange={(e) => updatePlano(i, { porque: e.target.value })} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <Field label="Quando?" type="date" value={p.quando} onChange={(v) => updatePlano(i, { quando: v })} />
                  <Field label="Onde?" value={p.onde} onChange={(v) => updatePlano(i, { onde: v })} />
                </div>
                <div className="space-y-1">
                  <Label>Como?</Label>
                  <Input value={p.como} onChange={(e) => updatePlano(i, { como: e.target.value })} />
                </div>
                <div className="space-y-1">
                  <Label>Abrangência (setor ou GHE)</Label>
                  <Input value={p.abrangencia} onChange={(e) => updatePlano(i, { abrangencia: e.target.value })} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Observações */}
        <Card>
          <CardHeader><CardTitle>Observações</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1">
              <Label>Detalhamento do ambiente de trabalho</Label>
              <Textarea rows={4} value={data.detalhamentoAmbiente} onChange={(e) => set("detalhamentoAmbiente", e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Outras observações</Label>
              <Textarea rows={4} value={data.outrasObservacoes} onChange={(e) => set("outrasObservacoes", e.target.value)} />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-2 pb-8">
          <Button variant="outline" onClick={saveAndBack} disabled={saving}>
            <Save className="h-4 w-4 mr-1" /> Salvar
          </Button>
          <Button onClick={saveAndPDF} disabled={saving}>
            <Download className="h-4 w-4 mr-1" /> Salvar e gerar PDF
          </Button>
        </div>
      </main>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <div className="space-y-1">
      <Label>
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <Input type={type} value={value} onChange={(e) => onChange(e.target.value)} required={required} />
    </div>
  );
}

function NumField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number | "";
  onChange: (v: number | "") => void;
}) {
  return (
    <div className="space-y-1">
      <Label>{label}</Label>
      <Select
        value={value === "" ? "" : String(value)}
        onValueChange={(v) => onChange(v === "" ? "" : Number(v))}
      >
        <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
        <SelectContent>
          {[1, 2, 3, 4, 5].map((n) => (
            <SelectItem key={n} value={String(n)}>{n}</SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function YesNo({
  label,
  value,
  onChange,
  required = false,
}: {
  label: string;
  value: "sim" | "nao" | "";
  onChange: (v: "sim" | "nao") => void;
  required?: boolean;
}) {
  return (
    <div className="space-y-1">
      <Label>
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <RadioGroup
        className="flex gap-4 pt-1"
        value={value}
        onValueChange={(v) => onChange(v as "sim" | "nao")}
      >
        <div className="flex items-center gap-1"><RadioGroupItem value="sim" id={`${label}-s`} /><Label htmlFor={`${label}-s`}>Sim</Label></div>
        <div className="flex items-center gap-1"><RadioGroupItem value="nao" id={`${label}-n`} /><Label htmlFor={`${label}-n`}>Não</Label></div>
      </RadioGroup>
    </div>
  );
}

function RatingScale({
  value,
  onChange,
  title,
}: {
  value: number;
  onChange: (v: number) => void;
  title: string;
}) {
  return (
    <div>
      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">{title}</div>
      <div className="flex gap-1 mt-0.5">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            onClick={() => onChange(value === n ? 0 : n)}
            className={`w-7 h-7 rounded text-xs font-semibold border transition-colors ${
              value === n
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-background hover:bg-muted"
            }`}
          >
            {n}
          </button>
        ))}
      </div>
    </div>
  );
}