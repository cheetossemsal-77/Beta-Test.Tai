import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Plus, Trash2, LogOut, Download, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { downloadAssessmentPDF } from "@/lib/generate-pdf";
import type { AssessmentData } from "@/lib/assessment-schema";

export const Route = createFileRoute("/_authenticated/app")({
  component: Dashboard,
});

type Row = {
  id: string;
  empresa: string;
  setor: string;
  cargo: string;
  data_visita: string | null;
  created_at: string;
  form_data: AssessmentData;
};

function Dashboard() {
  const navigate = useNavigate();
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["assessments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("assessments")
        .select("id, empresa, setor, cargo, data_visita, created_at, form_data")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Row[];
    },
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("assessments").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Levantamento excluído.");
      qc.invalidateQueries({ queryKey: ["assessments"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="bg-primary text-primary-foreground">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold">
            <ShieldCheck className="h-5 w-5" /> SST Levantamento
          </div>
          <Button variant="secondary" size="sm" onClick={signOut}>
            <LogOut className="h-4 w-4 mr-1" /> Sair
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Meus levantamentos</h1>
            <p className="text-muted-foreground text-sm">
              Cada empresa que você visita fica salva aqui.
            </p>
          </div>
          <Button asChild size="lg">
            <Link to="/novo">
              <Plus className="h-4 w-4 mr-1" /> Novo levantamento
            </Link>
          </Button>
        </div>

        {isLoading ? (
          <p className="text-muted-foreground">Carregando...</p>
        ) : !data || data.length === 0 ? (
          <Card>
            <CardContent className="py-16 flex flex-col items-center text-center gap-3">
              <FileText className="h-10 w-10 text-muted-foreground" />
              <div>
                <p className="font-semibold">Nenhum levantamento ainda</p>
                <p className="text-sm text-muted-foreground">
                  Comece criando o primeiro para gerar o PDF.
                </p>
              </div>
              <Button asChild>
                <Link to="/novo">
                  <Plus className="h-4 w-4 mr-1" /> Novo levantamento
                </Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3">
            {data.map((row) => (
              <Card key={row.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center justify-between gap-4">
                    <span>{row.empresa || "(sem empresa)"}</span>
                    <span className="text-xs font-normal text-muted-foreground">
                      {row.data_visita
                        ? new Date(row.data_visita).toLocaleDateString("pt-BR")
                        : new Date(row.created_at).toLocaleDateString("pt-BR")}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0 flex items-center justify-between gap-3 flex-wrap">
                  <p className="text-sm text-muted-foreground">
                    {[row.setor, row.cargo].filter(Boolean).join(" · ") || "—"}
                  </p>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => downloadAssessmentPDF(row.form_data)}
                    >
                      <Download className="h-4 w-4 mr-1" /> PDF
                    </Button>
                    <Button asChild size="sm" variant="secondary">
                      <Link to="/editar/$id" params={{ id: row.id }}>
                        Editar
                      </Link>
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        if (confirm("Excluir este levantamento?")) del.mutate(row.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}