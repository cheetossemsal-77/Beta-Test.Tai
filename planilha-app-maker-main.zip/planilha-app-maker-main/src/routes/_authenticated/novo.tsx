import { createFileRoute } from "@tanstack/react-router";
import { AssessmentForm } from "@/components/AssessmentForm";

export const Route = createFileRoute("/_authenticated/novo")({
  component: () => <AssessmentForm />,
});