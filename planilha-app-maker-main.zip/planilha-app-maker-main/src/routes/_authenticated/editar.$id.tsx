import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AssessmentForm } from "@/components/AssessmentForm";
import type { AssessmentData } from "@/lib/assessment-schema";
import { emptyAssessment } from "@/lib/assessment-schema";

export const Route = createFileRoute("/_authenticated/editar/$id")({
  component: EditPage,
});

function EditPage() {
  const { id } = Route.useParams();
  const { data, isLoading, error } = useQuery({
    queryKey: ["assessment", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("assessments")
        .select("form_data")
        .eq("id", id)
        .single();
      if (error) throw error;
      return data.form_data as unknown as AssessmentData;
    },
  });

  if (isLoading) return <div className="p-8 text-muted-foreground">Carregando...</div>;
  if (error) return <div className="p-8 text-destructive">Erro: {(error as Error).message}</div>;
  return <AssessmentForm id={id} initial={{ ...emptyAssessment(), ...data }} />;
}