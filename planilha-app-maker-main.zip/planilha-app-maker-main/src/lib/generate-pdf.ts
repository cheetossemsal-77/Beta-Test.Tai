import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import {
  RISK_GROUPS,
  EPI_GROUPS,
  riskLevel,
  type AssessmentData,
} from "./assessment-schema";

function fmtDate(iso: string): string {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return d && m && y ? `${d}/${m}/${y}` : iso;
}

function yesNo(v: string): string {
  if (v === "sim") return "Sim";
  if (v === "nao") return "Não";
  return "—";
}

function insalubridadeLabel(v: string): string {
  if (v === "nao") return "Não";
  if (v === "0.1") return "10%";
  if (v === "0.2") return "20%";
  if (v === "0.4") return "40%";
  return "—";
}

export function generateAssessmentPDF(data: AssessmentData): jsPDF {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();

  // --- Cover / Header ---
  doc.setFillColor(15, 40, 70);
  doc.rect(0, 0, pageW, 28, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont("helvetica", "bold");
  doc.text("Levantamento de Riscos Ocupacionais", 14, 13);
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(
    `Empresa: ${data.empresa || "—"}   •   Setor: ${data.setor || "—"}   •   Data: ${fmtDate(data.data)}`,
    14,
    22,
  );
  doc.setTextColor(0, 0, 0);

  // --- Identificação ---
  autoTable(doc, {
    startY: 34,
    theme: "grid",
    headStyles: { fillColor: [15, 40, 70], textColor: 255, fontStyle: "bold" },
    styles: { fontSize: 9, cellPadding: 2 },
    head: [[{ content: "Identificação", colSpan: 4 }]],
    body: [
      [
        { content: "Técnico responsável", styles: { fontStyle: "bold" } },
        data.tecnicoResponsavel || "—",
        { content: "Acompanhado por", styles: { fontStyle: "bold" } },
        data.acompanhadoPor || "—",
      ],
      [
        { content: "Empresa", styles: { fontStyle: "bold" } },
        data.empresa || "—",
        { content: "Data da visita", styles: { fontStyle: "bold" } },
        fmtDate(data.data),
      ],
      [
        { content: "Setor", styles: { fontStyle: "bold" } },
        data.setor || "—",
        { content: "GHE", styles: { fontStyle: "bold" } },
        data.ghe || "—",
      ],
      [
        { content: "Cargo", styles: { fontStyle: "bold" } },
        data.cargo || "—",
        { content: "Nº trabalhadores", styles: { fontStyle: "bold" } },
        data.numTrabalhadores || "—",
      ],
      [
        { content: "CBO", styles: { fontStyle: "bold" } },
        data.cbo || "—",
        { content: "GFIP", styles: { fontStyle: "bold" } },
        data.gfip || "—",
      ],
      [
        { content: "Telefone financeiro", styles: { fontStyle: "bold" } },
        data.telefoneFinanceiro || "—",
        { content: "Email financeiro", styles: { fontStyle: "bold" } },
        data.emailFinanceiro || "—",
      ],
      [
        { content: "Insalubridade", styles: { fontStyle: "bold" } },
        insalubridadeLabel(data.insalubridade),
        { content: "Periculosidade 30%", styles: { fontStyle: "bold" } },
        yesNo(data.periculosidade30),
      ],
      [
        { content: "Atividade proibida <18 anos", styles: { fontStyle: "bold" } },
        yesNo(data.atividadeMenor18),
        { content: "LUX", styles: { fontStyle: "bold" } },
        data.lux || "—",
      ],
      [
        { content: "Característica da exposição do GHE", styles: { fontStyle: "bold" } },
        { content: data.caracteristicaExposicaoGHE || "—", colSpan: 3 },
      ],
      [
        { content: "Descrição da atividade", styles: { fontStyle: "bold" } },
        { content: data.descricaoAtividade || "—", colSpan: 3 },
      ],
    ],
    columnStyles: { 0: { cellWidth: 42 }, 2: { cellWidth: 42 } },
  });

  // --- Legenda ---
  let y = (doc as any).lastAutoTable.finalY + 4;
  doc.setFontSize(8);
  doc.setFont("helvetica", "italic");
  doc.text(
    "Severidade: 1 Insignificante · 2 Menor · 3 Moderada · 4 Maior · 5 Catastrófica    |    Probabilidade: 1 Quase impossível · 2 Raro · 3 Improvável · 4 Provável · 5 Quase certo",
    14,
    y,
  );
  y += 4;

  // --- Grupos de risco ---
  for (const group of RISK_GROUPS) {
    const rows = group.items
      .map((it) => {
        const key = `${group.key}.${it.key}`;
        const r = data.riscos[key];
        if (!r || (!r.s && !r.p)) return null;
        const level = riskLevel(r.s, r.p);
        let label = it.label;
        const fonte = data.fontes?.[key];
        if (it.hasFonte && fonte) label += `\nFonte: ${fonte}`;
        const obs = data.observacoes?.[key];
        if (it.hasObs && obs) label += `\nObs.: ${obs}`;
        return [
          label,
          String(r.s || "—"),
          String(r.p || "—"),
          String((r.s || 0) * (r.p || 0) || "—"),
          { content: level.label, styles: { textColor: level.color, fontStyle: "bold" as const } },
        ];
      })
      .filter(Boolean) as any[];

    if (rows.length === 0) continue;

    autoTable(doc, {
      startY: y,
      theme: "grid",
      headStyles: { fillColor: [40, 80, 120], textColor: 255, fontStyle: "bold" },
      styles: { fontSize: 9, cellPadding: 2 },
      head: [
        [
          { content: group.title, colSpan: 5 },
        ],
        ["Agente / Risco", "Severidade", "Probabilidade", "Grau", "Classificação"],
      ],
      body: rows,
      columnStyles: {
        0: { cellWidth: "auto" },
        1: { cellWidth: 24, halign: "center" },
        2: { cellWidth: 28, halign: "center" },
        3: { cellWidth: 18, halign: "center" },
        4: { cellWidth: 28, halign: "center" },
      },
    });
    y = (doc as any).lastAutoTable.finalY + 3;
  }

  // --- EPIs ---
  const epiRows = EPI_GROUPS.map((g) => [g.label, data.epis[g.key] || "—"]);
  autoTable(doc, {
    startY: y,
    theme: "grid",
    headStyles: { fillColor: [15, 40, 70], textColor: 255, fontStyle: "bold" },
    styles: { fontSize: 9, cellPadding: 2 },
    head: [[{ content: "EPIs existentes / EPCs", colSpan: 2 }]],
    body: epiRows,
    columnStyles: { 0: { cellWidth: 55, fontStyle: "bold" } },
  });
  y = (doc as any).lastAutoTable.finalY + 4;

  // --- Plano de ação ---
  if (data.planoAcao.length > 0) {
    autoTable(doc, {
      startY: y,
      theme: "grid",
      headStyles: { fillColor: [15, 40, 70], textColor: 255, fontStyle: "bold" },
      styles: { fontSize: 8, cellPadding: 1.8, valign: "top" },
      head: [
        [{ content: "Plano de Ação (Matriz GUT)", colSpan: 8 }],
        ["Medida (O quê?)", "G", "U", "T", "Por quê?", "Quando?", "Onde? / Como?", "Abrangência"],
      ],
      body: data.planoAcao.map((p) => [
        p.medida || "—",
        String(p.g || "—"),
        String(p.u || "—"),
        String(p.t || "—"),
        p.porque || "—",
        p.quando ? fmtDate(p.quando) : "—",
        [p.onde, p.como].filter(Boolean).join(" / ") || "—",
        p.abrangencia || "—",
      ]),
      columnStyles: {
        0: { cellWidth: 32 },
        1: { cellWidth: 8, halign: "center" },
        2: { cellWidth: 8, halign: "center" },
        3: { cellWidth: 8, halign: "center" },
        6: { cellWidth: 32 },
      },
    });
    y = (doc as any).lastAutoTable.finalY + 4;
  }

  // --- Detalhamento / Observações ---
  if (data.detalhamentoAmbiente || data.outrasObservacoes) {
    autoTable(doc, {
      startY: y,
      theme: "grid",
      headStyles: { fillColor: [15, 40, 70], textColor: 255, fontStyle: "bold" },
      styles: { fontSize: 9, cellPadding: 2 },
      head: [[{ content: "Observações", colSpan: 1 }]],
      body: [
        [
          {
            content:
              (data.detalhamentoAmbiente
                ? `Detalhamento do ambiente de trabalho:\n${data.detalhamentoAmbiente}\n\n`
                : "") +
              (data.outrasObservacoes ? `Outras observações:\n${data.outrasObservacoes}` : ""),
          },
        ],
      ],
    });
  }

  // Footer + assinatura em todas as páginas
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    const h = doc.internal.pageSize.getHeight();
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text(
      `Gerado em ${new Date().toLocaleString("pt-BR")}   —   Página ${i} de ${pageCount}`,
      14,
      h - 6,
    );
  }

  return doc;
}

export function downloadAssessmentPDF(data: AssessmentData) {
  const doc = generateAssessmentPDF(data);
  const safe = (s: string) => s.replace(/[^a-z0-9]+/gi, "_").replace(/^_|_$/g, "");
  const name = `levantamento_${safe(data.empresa) || "empresa"}_${data.data || "data"}.pdf`;
  doc.save(name);
}