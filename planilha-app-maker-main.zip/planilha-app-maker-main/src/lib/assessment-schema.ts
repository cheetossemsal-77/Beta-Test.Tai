// Data model for a safety inspection (Levantamento de Riscos).
// Every "risk item" gets a severity 1-5 and probability 1-5 rating.

export type RiskRating = { s: number; p: number };

export type RiskGroupDef = {
  key: string;
  title: string;
  items: {
    key: string;
    label: string;
    hasFonte?: boolean;
    hasObs?: boolean;
  }[];
};

export const RISK_GROUPS: RiskGroupDef[] = [
  {
    key: "fisicos",
    title: "Agentes Físicos",
    items: [
      { key: "ruidoNR15", label: "Ruído — NR 15", hasObs: true },
      { key: "ruidoNHO01", label: "Ruído — NHO 01", hasObs: true },
      { key: "radiacaoIonizante", label: "Radiação ionizante (Raio-X)" },
      { key: "radNaoIonSolar", label: "Radiação não ionizante — Solar" },
      { key: "radNaoIonSolda", label: "Radiação não ionizante — Solda" },
      { key: "radNaoIonFornalha", label: "Radiação não ionizante — Fornalha" },
      { key: "calor", label: "Calor", hasFonte: true },
      { key: "frio", label: "Frio", hasFonte: true },
      { key: "vibracao", label: "Vibração", hasFonte: true },
      { key: "umidade", label: "Umidade", hasFonte: true },
    ],
  },
  {
    key: "quimicos",
    title: "Agentes Químicos",
    items: [
      { key: "substancias", label: "Substâncias químicas" },
      { key: "poeiras", label: "Poeiras" },
      { key: "domissanitarios", label: "Produtos domissanitários" },
      { key: "fumosMetalicos", label: "Fumos metálicos" },
      { key: "gasesVapores", label: "Gases / Vapores" },
    ],
  },
  {
    key: "biologicos",
    title: "Agentes Biológicos",
    items: [
      { key: "agentesBiologicos", label: "Agentes biológicos", hasFonte: true },
      { key: "estabelecimentosSaude", label: "Trabalhos em estabelecimentos de saúde" },
      { key: "animaisInfectados", label: "Trabalhos com animais infectados" },
      { key: "coletaLixo", label: "Coleta de lixo" },
    ],
  },
  {
    key: "ergonomicos",
    title: "Agentes Ergonômicos",
    items: [
      { key: "vicioPosturalComputador", label: "Vício postural — Computador" },
      { key: "vicioPosturalNotebook", label: "Vício postural — Notebook" },
      { key: "esforcoFisico", label: "Esforço físico" },
      { key: "posturaEmPe", label: "Postura em pé por longos períodos" },
      { key: "posturaSentada", label: "Postura sentada por longos períodos" },
    ],
  },
  {
    key: "mecanicos",
    title: "Agentes Mecânicos / Acidentes",
    items: [
      { key: "acidenteTransito", label: "Acidente de trânsito" },
      { key: "atropelamento", label: "Atropelamento" },
      { key: "queimaduras", label: "Queimaduras" },
      { key: "animaisPeconhentos", label: "Animais peçonhentos" },
      { key: "lesaoMembrosSuperiores", label: "Lesão de membros superiores" },
      { key: "lesaoMembrosInferiores", label: "Lesão de membros inferiores" },
      { key: "tombamento", label: "Tombamento" },
      { key: "espacoConfinado", label: "Espaço confinado" },
      { key: "incendioCombustivel", label: "Incêndio — Combustível" },
      { key: "incendioGLP", label: "Incêndio — GLP" },
      { key: "explosaoCombustivel", label: "Explosão — Combustível" },
      { key: "explosaoGLP", label: "Explosão — GLP" },
      { key: "quedasObjetos", label: "Quedas de objetos" },
      { key: "quedasMesmoNivel", label: "Quedas mesmo nível" },
      { key: "trabalhoAltura", label: "Trabalho em altura" },
      { key: "projecaoParticulas", label: "Projeção de partículas" },
      { key: "eletricidadeAlta", label: "Eletricidade — Alta tensão" },
      { key: "eletricidadeBaixa", label: "Eletricidade — Baixa tensão" },
    ],
  },
];

export const EPI_GROUPS = [
  { key: "fisico", label: "EPI/EPC - Risco Físico" },
  { key: "quimico", label: "EPI/EPC - Risco Químico" },
  { key: "biologico", label: "EPI/EPC - Risco Biológico" },
  { key: "mecanico", label: "EPI/EPC - Risco Mecânico" },
  { key: "ergonomico", label: "EPI/EPC - Risco Ergonômico" },
] as const;

export type PlanoAcaoItem = {
  medida: string;
  g: number | "";
  u: number | "";
  t: number | "";
  porque: string;
  quando: string;
  onde: string;
  como: string;
  abrangencia: string;
};

export type AssessmentData = {
  // Cabeçalho
  tecnicoResponsavel: string;
  acompanhadoPor: string;
  data: string;
  telefoneFinanceiro: string;
  emailFinanceiro: string;
  empresa: string;
  setor: string;
  ghe: string;
  cargo: string;
  caracteristicaExposicaoGHE: string;
  numTrabalhadores: string;
  cbo: string;
  insalubridade: "nao" | "0.1" | "0.2" | "0.4" | "";
  gfip: string;
  periculosidade30: "sim" | "nao" | "";
  atividadeMenor18: "sim" | "nao" | "";
  lux: string;
  descricaoAtividade: string;

  // Riscos: mapping "groupKey.itemKey" -> RiskRating
  riscos: Record<string, RiskRating>;

  // Fonte livre para itens com hasFonte (chave "groupKey.itemKey")
  fontes: Record<string, string>;
  // Observação livre para itens com hasObs (chave "groupKey.itemKey")
  observacoes: Record<string, string>;

  // EPIs por risco
  epis: Record<string, string>;

  // Plano de ação
  planoAcao: PlanoAcaoItem[];

  detalhamentoAmbiente: string;
  outrasObservacoes: string;
};

export function emptyAssessment(): AssessmentData {
  return {
    tecnicoResponsavel: "",
    acompanhadoPor: "",
    data: new Date().toISOString().slice(0, 10),
    telefoneFinanceiro: "",
    emailFinanceiro: "",
    empresa: "",
    setor: "",
    ghe: "",
    cargo: "",
    caracteristicaExposicaoGHE: "",
    numTrabalhadores: "",
    cbo: "",
    insalubridade: "",
    gfip: "",
    periculosidade30: "",
    atividadeMenor18: "",
    lux: "",
    descricaoAtividade: "",
    riscos: {},
    fontes: {},
    observacoes: {},
    epis: { fisico: "", quimico: "", biologico: "", mecanico: "", ergonomico: "" },
    planoAcao: [],
    detalhamentoAmbiente: "",
    outrasObservacoes: "",
  };
}

export function riskLevel(s: number, p: number): { label: string; color: [number, number, number] } {
  const v = s * p;
  if (v <= 4) return { label: "Baixo", color: [34, 139, 34] };
  if (v <= 9) return { label: "Moderado", color: [218, 165, 32] };
  if (v <= 16) return { label: "Alto", color: [220, 100, 30] };
  return { label: "Crítico", color: [200, 40, 40] };
}